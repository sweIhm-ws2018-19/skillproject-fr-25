package gehirnjogging;
import gehirnjogging.GehirnjoggingStreamHandler;
import org.junit.Test;

public class GehirnjoggingStreamHanlderTest {

    @Test
    public void testInitailaize() {
        GehirnjoggingStreamHandler test = new GehirnjoggingStreamHandler();
    }


}
