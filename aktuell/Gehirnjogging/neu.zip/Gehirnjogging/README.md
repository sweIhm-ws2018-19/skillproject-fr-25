﻿# Alexa Skills Kit SDK Sample - Train your Brain - Gehirnjogging
### Beschreibung
Anwendung für interaktives Training der geistigen Fähigkeiten.

### Ziel
Mit dem Skill soll sowohl sinnvoller Kontext vermittelt, als auch die geistige Fitness verbessert werden. Dabei soll der Nutzer gebildet und unterhalten werden.

### Hauptanforderungen:
Nummern merken Begriffe merken Allgemeinwissen abfragen Rechenaufgaben rückwärts zählen Single-/Multiplayer