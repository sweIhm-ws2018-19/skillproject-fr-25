package main.java.gehirnjogging.handlers;

import static com.amazon.ask.request.Predicates.intentName;

import java.util.Optional;
import com.amazon.ask.dispatcher.request.handler.HandlerInput;
import com.amazon.ask.dispatcher.request.handler.RequestHandler;
import com.amazon.ask.model.Response;



public class RegelHandler implements RequestHandler { {

}

@Override
public boolean canHandle(HandlerInput input) {
    return input.matches(intentName("RegelIntent"));
}

@Override
public Optional<Response> handle(HandlerInput input) {
    return input.getResponseBuilder()
            .withSpeech("Wenn du bei einem Quiz nach den Regeln fragen muss bist du wohl noch zu Jung du Lauch Haha um zu starten sage los")
            .withReprompt("bist du eingeschlafen ?")
            .build();
}
}
