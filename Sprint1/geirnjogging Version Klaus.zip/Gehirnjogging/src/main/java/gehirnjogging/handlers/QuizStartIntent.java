package main.java.gehirnjogging.handlers;

import java.util.Optional;

import static com.amazon.ask.request.Predicates.intentName;

import com.amazon.ask.dispatcher.request.handler.HandlerInput;
import com.amazon.ask.dispatcher.request.handler.RequestHandler;
import com.amazon.ask.model.Response;

public class QuizStartIntent implements RequestHandler {
	{

	}

	@Override
	public boolean canHandle(HandlerInput input) {
		return input.matches(intentName("StartGameIntent"));
	}

	@Override
	public Optional<Response> handle(HandlerInput input) {
		 return input.getResponseBuilder()
		            .withSpeech("Hier kommt die erste Frage:  Was ist das beste Bier auf der ganzen Welt ? <break time=\"5s\"/> Haha diese Frage ist eine Retorischefrage da die antwort jeder kenn <break time=\"2s\"/> Augustiner ist das beste!")
		            .withReprompt("bist du eingeschlafen ?")
		            .build();
	}
}
